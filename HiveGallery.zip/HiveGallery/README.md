# Hive Gallery

Native Android gallery prototype inspired by the V5 Hive design: rounded honeycomb media, AMOLED black, radial magnification, elastic vertical scrolling, horizontal batches, chronological section headings, staggered entry, and a floating spring-animated glass navigation bar.

## What is included

- Actual local photos and videos via Android MediaStore (full or selected access on Android 14+).
- Alternating five/six-item rows with smoothly magnified central media, adaptive spacing, and 4–6 dp rounded corners.
- Elastic scroll and older/newer batches (132 media items maximum per batch), day/month/year dividers, per-tab position restoration, and center-out staggered entry.
- Pictures, Albums, Stories (date-based collections, not AI-generated stories), Favourites, search, selection, image viewer, video playback, native sharing and local favourites.
- Light/dark themes, animation settings, reduced-motion respect, and accessible list fallback.
- Native RenderNode backdrop blur on Android 12+; translucent fallback on Android 10–11. This is a Liquid Glass-inspired effect, not Apple's proprietary optical refraction.
- GitHub Actions signed APK release and in-app update checker/downloader.

**Status:** Source project, not a device-tested APK. Android SDK/Gradle and network were unavailable in the creation environment. Build and test it in GitHub Actions or Android Studio. The project is Java 17, AGP 8.7.3, Gradle 8.9, SDK 35, min SDK 29. No NDK, server, or paid library is required. No photos are uploaded. The app uses the network only to retrieve update files from GitHub. There is no deletion/editing feature in this initial build. Smoothness, device compatibility, accessibility, blur, and memory behavior must be checked on actual hardware.

## Single-repository deployment (recommended)

Use **one public GitHub repository**, e.g. `YOUR_USERNAME/HiveGallery`. The workflow publishes signed APKs to that same repository's Releases. Public visibility is needed for this implementation's unauthenticated download. This makes source and APK public, but not your device photos or signing secrets. For private source code, see the note below.

### 1. Upload the project

Extract `HiveGallery.zip`. The repository root must directly contain `settings.gradle`, `build.gradle`, `app/`, `scripts/` and `.github/workflows/build-apk.yml`. Do not create an extra nested `HiveGallery/` or `source/` directory.

From a computer:

```bash
cd HiveGallery
git init
git add .
git commit -m "Initial Hive Gallery"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/HiveGallery.git
git push -u origin main
```

Create the empty GitHub repository first and authenticate Git. Do not use a repository initialized with a conflicting README for these exact commands.

**From your phone only:**

1. Open github.com in a mobile browser (desktop site mode if necessary). Create a public `HiveGallery` repository with a README.
2. Use Add file → Upload files to commit `HiveGallery.zip` temporarily in the root. This is the project ZIP, not a signing key.
3. Open Code → Codespaces → Create codespace on main. If Codespaces is available on your account, open the web terminal and run:

```bash
unzip -o HiveGallery.zip
cp -a HiveGallery/. .
rm -rf HiveGallery HiveGallery.zip
git add -A
git commit -m "Add native Hive project and release workflow"
git push
```

The ZIP contains a top-level `HiveGallery/` folder, so these commands work from the repository root. This is a one-time setup. Codespaces availability, quotas and usability on mobile vary; the GitHub Actions build itself does not need a Codespace or computer. If workflow-file push is rejected due to authentication scope, add `.github/workflows/build-apk.yml` via GitHub's web editor or authenticate with appropriately scoped credentials. Never place a personal access token in the app.

### 2. Generate a permanent signing key (once)

Use a trusted computer or your private Codespace terminal with JDK installed:

```bash
bash scripts/create-signing-key.sh
```

If `keytool` is missing in a Codespace, install JDK 17 using the environment's package manager, for example `sudo apt-get update && sudo apt-get install -y openjdk-17-jdk`. Choose a strong password. The alias is `hive`. PKCS12 uses the same password for key and store. **Keep a secure backup of `hive-signing.p12` and the password.** Never commit it; the `.gitignore` excludes it. You can download the ignored file from the Codespace Explorer to encrypted storage. If the signing key is lost, you normally cannot update the existing sideloaded app without uninstalling it first.

Encode the key locally in the terminal (not an online base64 service):

```bash
base64 -w 0 hive-signing.p12
```

On macOS: `base64 < hive-signing.p12 | tr -d '\n'`.

In GitHub → repository Settings → Secrets and variables → Actions → New repository secret, add:

| Name | Value |
| --- | --- |
| `HIVE_KEYSTORE_BASE64` | The complete single-line base64 output |
| `HIVE_STORE_PASSWORD` | Your keystore password |
| `HIVE_KEY_ALIAS` | `hive` |
| `HIVE_KEY_PASSWORD` | The same password for this PKCS12 key |

The base64 string is not encryption. Treat it as the private key. Do not paste it into issues, chats, files, or commit logs. Clear clipboard/history where practical. Do not run untrusted workflow changes with the signing secrets. Restrict write access to your repository.

### 3. Build and publish

Open Actions → **Build and publish Hive APK** → Run workflow (main branch). Leave the optional version name blank or enter e.g. `1.0.0`. The workflow installs Gradle and Android SDK, signs the APK, verifies its signature and manifest, creates the SHA-256 update metadata, and publishes a release.

The build uses `versionCode = 100 + GITHUB_RUN_NUMBER`. Each new run gets a higher code. A failed run can be retried if it has not published; after publishing, dispatch a new run, rather than overwriting an existing release. If you edit the workflow name/path or migrate repositories, retain monotonically increasing version codes.

No additional deployment repository, GitHub App, personal access token, OTA hosting service, or separate packaging script is needed. GitHub Actions uses the job-scoped `GITHUB_TOKEN` with `contents: write` to publish. Check that repository/organization Actions policy permits this. Only run releases from the trusted main branch.

Release assets:

```text
Hive.apk
update.json
```

The APK is built with `BuildConfig.UPDATE_REPO` automatically set to the current GitHub repository. `update.json` contains the package name, version name, version code, release tag, byte length and SHA-256. Do not manually change these files after publication.

### 4. First installation

On the phone, open `https://github.com/YOUR_USERNAME/HiveGallery/releases/latest` and download `Hive.apk`. Open the downloaded file and allow your browser or file manager to install unknown apps if Android prompts you. Install Hive and allow full or selected media access. On Samsung devices an enabled Auto Blocker or enterprise policy may prevent sideloading; only change your own device's security settings if you understand the implications, and restore them when appropriate. Do not bypass a managed-device policy.

### 5. Future OTA updates from your phone

1. Commit a change to the same repository (web editor, Codespaces, GitHub client, or your coding agent).
2. Dispatch **Build and publish Hive APK** again. Wait for the workflow to succeed and a new release to be published.
3. Open Hive. It checks the latest release once per Activity launch when it has media access. You can also use `⋯ → Check for updates` any time, even without media permission.
4. Approve the download. Hive verifies the APK length, SHA-256, package name, higher version code and matching signing certificates. Android also verifies its signature during installation.
5. If asked, enable **Allow from this source** for Hive. Return to the app and approve the Android installer. If you cancel, use `⋯ → Install downloaded update` later.

This is an in-place, full-APK update, not a firmware OTA or silent background install. It does not erase local app favourites/settings if package and signer match. Downloaded release APK is stored in app-private cache; cache may be cleared by Android. The installer is always user-confirmed. Network/update errors leave the installed version unchanged.

Updater endpoint:

```text
https://github.com/OWNER/REPO/releases/latest/download/update.json
```

APK endpoint is pinned to the exact release tag specified by the checked metadata, not a moving `latest` link. The app only follows HTTPS GitHub/GitHubusercontent redirects and verifies the installed certificate before invoking the installer. Keep your GitHub account and signing key secure.

### Private repository note

A private GitHub repository cannot serve unauthenticated release downloads. If you need a private repo, manually download the release in an authenticated GitHub browser and install it over the current app, or add a secure authenticated update service. Do not embed a GitHub token into the APK. The provided one-repository automatic updater assumes public releases.

## Local build (optional)

Install Android Studio or Gradle 8.9, JDK 17, Android SDK 35 and Build Tools 35.0.0. Set `ANDROID_HOME` or `local.properties` appropriately. The ZIP does not include the Gradle wrapper binaries; CI installs the exact Gradle version, so it does not need them.

```bash
gradle --version
gradle :app:assembleDebug -PhiveRepo=YOUR_USERNAME/HiveGallery
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

A debug APK cannot be updated by the release APK signed with a different key. Install the signed release from the beginning on your primary phone. For a local signed build, export `HIVE_KEYSTORE` (absolute path), `HIVE_STORE_PASSWORD`, `HIVE_KEY_ALIAS`, `HIVE_KEY_PASSWORD`, and specify a version code higher than the installed one:

```bash
gradle :app:assembleRelease -PhiveRepo=YOUR_USERNAME/HiveGallery -PhiveCode=101 -PhiveVersion=1.0.0
```

Only use that local code if it does not conflict with published codes. For Android Studio, open the folder and sync using the installed Gradle 8.9 distribution, or generate a wrapper with `gradle wrapper --gradle-version 8.9` on a trusted machine.

## Device acceptance checklist

- [ ] Successful CI build, signed release assets, installation on Android 10 and Android 12+ (especially your Samsung device).
- [ ] Allow all photos/videos and selected-only access; revoke and regrant permission; app does not crash.
- [ ] Scroll from latest to oldest dates; check small trailing media, 3–4 dominant center items, gaps, day/month/year markers and partial rows.
- [ ] Horizontal swipe both directions on a library with >132 items, including first/last boundary rebound and rapid reversals.
- [ ] Switch all four tabs rapidly, open an album/story, return and confirm stagger, bounce and restoration.
- [ ] Verify media is visible behind navigation; blur works on Android 12+, translucent fallback on 10–11; light mode remains readable.
- [ ] Open photo/video, swipe next/previous, play video, share, long press/select, save favourites, restart and confirm persistence.
- [ ] Reduced motion disabled/enabled; accessible media list; rotation; large library memory and frame time.
- [ ] Publish a second release; verify in-app download and install, app data retained. Try a corrupted APK and wrong signer in a test repository: updater must reject them.
- [ ] Test offline and interrupted download; app should remain functional.

Use `adb shell dumpsys gfxinfo com.hive.gallery` or Android Studio profiler to measure frame performance; 120 Hz is a target, not a verified guarantee. Test on a small and very large library before relying on the gallery.
