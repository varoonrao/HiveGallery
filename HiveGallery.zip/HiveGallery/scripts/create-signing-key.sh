#!/usr/bin/env bash
# Run once, on a trusted computer or private Codespace. Do not commit the key.
set -euo pipefail
umask 077
KEY="${1:-hive-signing.p12}"
if [[ -e "$KEY" ]]; then echo 'Key already exists; refusing to overwrite it.' >&2; exit 1; fi
keytool -genkeypair -v -storetype PKCS12 -keystore "$KEY" -alias hive \
  -keyalg RSA -keysize 3072 -validity 10000 -dname 'CN=Hive Gallery'
echo 'Back up the keystore and password securely. PKCS12 uses the same password for the store and key.'
echo 'To add HIVE_KEYSTORE_BASE64, run: base64 -w 0 hive-signing.p12 (Linux) or base64 < hive-signing.p12 | tr -d "\n" (macOS).'
